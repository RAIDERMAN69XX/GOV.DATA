<?php
/*
Template Name: Suggest Dataset
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'suggest'); ?>