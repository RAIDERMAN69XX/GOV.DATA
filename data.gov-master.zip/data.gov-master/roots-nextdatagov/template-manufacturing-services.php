<?php
/*
Template Name:Manufacturing Services
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'manufacturing-services'); ?>