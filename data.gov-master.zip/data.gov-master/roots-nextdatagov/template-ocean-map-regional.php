<?php
/*
Template Name:Ocean Map Regional
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'ocean-map-regional'); ?>