<?php
/*
Template Name:All Applications
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'all-apps'); ?>
