<?php
/*
Template Name: Categories-Blog
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'categories-blog'); ?>