<?php
/*
Template Name:All Challanges
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'all-challanges'); ?>
