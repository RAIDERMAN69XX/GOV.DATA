<?php
/*
Template Name: CKAN Harvest Metrics
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'harvest-metrics'); ?>