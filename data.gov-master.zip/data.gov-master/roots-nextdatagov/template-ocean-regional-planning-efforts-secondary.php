<?php
/*
Template Name:Ocean Regional Planning Efforts Secondary
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'ocean-regional-planning-efforts-secondary'); ?>