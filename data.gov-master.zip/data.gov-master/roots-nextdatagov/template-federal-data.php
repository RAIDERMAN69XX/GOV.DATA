<?php
/*
Template Name:Federal and non federal data
*/
?>

<?php get_template_part('templates/page', 'header'); ?>
<?php get_template_part('templates/content', 'federal-data'); ?>
