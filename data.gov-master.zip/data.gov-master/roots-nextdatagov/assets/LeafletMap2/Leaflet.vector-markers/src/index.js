import L from 'leaflet'
import VectorMarkers from './VectorMarkers'
export VectorMarkers from './VectorMarkers'
export Icon from './Icon'

L.VectorMarkers = VectorMarkers
